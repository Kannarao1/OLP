package com.ibm;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class Log4jUtil {

	public static String levelType = "INFO";
	public static String loggerName = "default";
	public static Logger log = Logger.getLogger(Log4jUtil.loggerName);

	public static void setValues(String level, String logger) {
		Log4jUtil.levelType = level;
		Log4jUtil.loggerName = logger;
		Log4jUtil.log = Logger.getLogger(Log4jUtil.loggerName);
	}

	public static void setLogger(String level, String logger) {
		setValues(level,logger);
		initLogger(Log4jUtil.levelType = level, Log4jUtil.loggerName = logger);
	}

	public static void initLogger(String level, String loggerName) {

		Log4jUtil.log.setLevel(Level.toLevel(level));

	}
}
